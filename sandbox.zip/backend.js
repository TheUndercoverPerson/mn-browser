(async() => {
    await
    import ('./src/server.mjs');
})();